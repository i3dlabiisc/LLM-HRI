## Author: Mukund Mitra (email: mukundmitra@iisc.ac.in)
## License: MIT License, Copyright (c) 2023 Mukund Mitra
## Citation: [1] M. Mitra, G. Kumar, P. P. Chakrabarti and P. Biswas, "Enhanced Human-Robot Collaboration with Intent Prediction using Deep Inverse Reinforcement Learning," 2024 IEEE International Conference on Robotics and Automation (ICRA), Yokohama, Japan, 2024, pp. 7880-7887, doi: 10.1109/ICRA57147.2024.10610595. keywords: {Measurement;Accuracy;Collaboration;Reinforcement learning;Handover;Task analysis;Robots},
## [2] Mukund Mitra, Gyanig Kumar, Partha Pratim Chakrabarti, and Pradipta Biswas. 2025. Investigating Inverse Reinforcement Learning during Rapid Aiming Movement in Extended Reality and Human-Robot Interaction. J. Hum.-Robot Interact. Just Accepted (May 2025). https://doi.org/10.1145/3736423
## [3] Mukund Mitra, Ameya Avinash Patil, Gvs Mothish, Gyanig Kumar, Abhishek Mukhopadhyay, Murthy L R D, Partha Pratim Chakraborty, and Pradipta Biswas. 2024. Multimodal Target Prediction for Rapid Human-Robot Interaction. In Companion Proceedings of the 29th International Conference on Intelligent User Interfaces (IUI '24 Companion). Association for Computing Machinery, New York, NY, USA, 18–23. https://doi.org/10.1145/3640544.3645229

import torch
import torch.nn as nn
import torch.optim as optim

class RewardNet(nn.Module):
    def __init__(self, input_dim=4):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, 128), nn.ReLU(),
            nn.Linear(128, 128), nn.ReLU(),
            nn.Linear(128, 128), nn.ReLU(),
            nn.Linear(128, 128), nn.ReLU(),
            nn.Linear(128, 1)
        )

    def forward(self, features):
        return self.net(features).squeeze(-1)

class MEDIRL:
    def __init__(self, reward_net, lr=1e-3):
        self.reward_net = reward_net
        self.optimizer = optim.Adam(self.reward_net.parameters(), lr=lr)

    def train_step(self, expert_feats, sampled_feats):
        expert_feats = expert_feats.detach().requires_grad_(True)
        sampled_feats = sampled_feats.detach().requires_grad_(True)

        R_expert = self.reward_net(expert_feats)
        R_sample = self.reward_net(sampled_feats)
        mu_expert = expert_feats.mean(dim=0)
        weights = torch.softmax(R_sample, dim=0)
        mu_sampled = (sampled_feats.T @ weights).T
        feature_diff = (mu_expert - mu_sampled).detach()

        loss = torch.dot(feature_diff, torch.ones_like(feature_diff))
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

        return {
            "reward_mean_expert": R_expert.mean().item(),
            "reward_mean_sampled": R_sample.mean().item(),
            "grad_norm": feature_diff.norm().item()
        }
