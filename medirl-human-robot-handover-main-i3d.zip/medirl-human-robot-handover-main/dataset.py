## Author: Mukund Mitra (email: mukundmitra@iisc.ac.in)
## License: MIT License, Copyright (c) 2023 Mukund Mitra
## Citation: [1] M. Mitra, G. Kumar, P. P. Chakrabarti and P. Biswas, "Enhanced Human-Robot Collaboration with Intent Prediction using Deep Inverse Reinforcement Learning," 2024 IEEE International Conference on Robotics and Automation (ICRA), Yokohama, Japan, 2024, pp. 7880-7887, doi: 10.1109/ICRA57147.2024.10610595. keywords: {Measurement;Accuracy;Collaboration;Reinforcement learning;Handover;Task analysis;Robots},
## [2] Mukund Mitra, Gyanig Kumar, Partha Pratim Chakrabarti, and Pradipta Biswas. 2025. Investigating Inverse Reinforcement Learning during Rapid Aiming Movement in Extended Reality and Human-Robot Interaction. J. Hum.-Robot Interact. Just Accepted (May 2025). https://doi.org/10.1145/3736423
## [3] Mukund Mitra, Ameya Avinash Patil, Gvs Mothish, Gyanig Kumar, Abhishek Mukhopadhyay, Murthy L R D, Partha Pratim Chakraborty, and Pradipta Biswas. 2024. Multimodal Target Prediction for Rapid Human-Robot Interaction. In Companion Proceedings of the 29th International Conference on Intelligent User Interfaces (IUI '24 Companion). Association for Computing Machinery, New York, NY, USA, 18–23. https://doi.org/10.1145/3640544.3645229

import torch

def generate_dummy_traj(start, goal, T=20):
    timestamps = torch.linspace(0, 1, T)
    pos = torch.stack([(1 - t) * start + t * goal for t in timestamps])
    return pos, timestamps

def load_dummy_data(num=10):
    goals = [torch.tensor([1,0,0]), torch.tensor([0,1,0]),
             torch.tensor([0,0,1]), torch.tensor([1,1,1])]
    trajs_by_goal = {}
    for gid, goal in enumerate(goals):
        trajs = []
        for _ in range(num):
            start = torch.rand(3)
            traj, ts = generate_dummy_traj(start, goal)
            trajs.append((traj, goal, ts))
        trajs_by_goal[gid] = trajs
    return trajs_by_goal, goals
