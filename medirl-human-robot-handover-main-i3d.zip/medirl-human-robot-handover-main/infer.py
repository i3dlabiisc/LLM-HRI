## Author: Mukund Mitra (email: mukundmitra@iisc.ac.in)
## License: MIT License, Copyright (c) 2023 Mukund Mitra
## Citation: [1] M. Mitra, G. Kumar, P. P. Chakrabarti and P. Biswas, "Enhanced Human-Robot Collaboration with Intent Prediction using Deep Inverse Reinforcement Learning," 2024 IEEE International Conference on Robotics and Automation (ICRA), Yokohama, Japan, 2024, pp. 7880-7887, doi: 10.1109/ICRA57147.2024.10610595. keywords: {Measurement;Accuracy;Collaboration;Reinforcement learning;Handover;Task analysis;Robots},
## [2] Mukund Mitra, Gyanig Kumar, Partha Pratim Chakrabarti, and Pradipta Biswas. 2025. Investigating Inverse Reinforcement Learning during Rapid Aiming Movement in Extended Reality and Human-Robot Interaction. J. Hum.-Robot Interact. Just Accepted (May 2025). https://doi.org/10.1145/3736423
## [3] Mukund Mitra, Ameya Avinash Patil, Gvs Mothish, Gyanig Kumar, Abhishek Mukhopadhyay, Murthy L R D, Partha Pratim Chakraborty, and Pradipta Biswas. 2024. Multimodal Target Prediction for Rapid Human-Robot Interaction. In Companion Proceedings of the 29th International Conference on Intelligent User Interfaces (IUI '24 Companion). Association for Computing Machinery, New York, NY, USA, 18–23. https://doi.org/10.1145/3640544.3645229

from medirl import RewardNet
from features import compute_analytical_features
from utils import load_model
import torch

def predict_goal(partial_traj, trajs_by_goal, model_path='reward_model.pt'):
    model = RewardNet()
    load_model(model, model_path)

    f_obs = compute_analytical_features(*partial_traj)
    log_probs = []

    for goal_id, trajs in trajs_by_goal.items():
        feats = torch.stack([compute_analytical_features(*traj) for traj in trajs])
        rewards = model(feats)
        log_Z = torch.logsumexp(rewards, dim=0)
        log_P = model(f_obs.unsqueeze(0)).item() - log_Z.item()
        log_probs.append(log_P)

    probs = torch.softmax(torch.tensor(log_probs), dim=0)
    pred_goal = torch.argmax(probs).item()
    return pred_goal, probs.tolist()