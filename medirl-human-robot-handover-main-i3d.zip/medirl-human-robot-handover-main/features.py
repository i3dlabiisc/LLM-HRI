## Author: Mukund Mitra (email: mukundmitra@iisc.ac.in)
## License: MIT License, Copyright (c) 2023 Mukund Mitra
## Citation: [1] M. Mitra, G. Kumar, P. P. Chakrabarti and P. Biswas, "Enhanced Human-Robot Collaboration with Intent Prediction using Deep Inverse Reinforcement Learning," 2024 IEEE International Conference on Robotics and Automation (ICRA), Yokohama, Japan, 2024, pp. 7880-7887, doi: 10.1109/ICRA57147.2024.10610595. keywords: {Measurement;Accuracy;Collaboration;Reinforcement learning;Handover;Task analysis;Robots},
## [2] Mukund Mitra, Gyanig Kumar, Partha Pratim Chakrabarti, and Pradipta Biswas. 2025. Investigating Inverse Reinforcement Learning during Rapid Aiming Movement in Extended Reality and Human-Robot Interaction. J. Hum.-Robot Interact. Just Accepted (May 2025). https://doi.org/10.1145/3736423
## [3] Mukund Mitra, Ameya Avinash Patil, Gvs Mothish, Gyanig Kumar, Abhishek Mukhopadhyay, Murthy L R D, Partha Pratim Chakraborty, and Pradipta Biswas. 2024. Multimodal Target Prediction for Rapid Human-Robot Interaction. In Companion Proceedings of the 29th International Conference on Intelligent User Interfaces (IUI '24 Companion). Association for Computing Machinery, New York, NY, USA, 18–23. https://doi.org/10.1145/3640544.3645229

import torch

def desired_velocity(distance):
    return 0.1 * distance**2 - 0.2 * distance + 0.3

def compute_analytical_features(states, goal, timestamps):
    N = len(states)
    states = torch.stack(states)
    d_current = torch.norm(goal - states, dim=1)
    d_shortest = torch.norm(goal - states[0])
    f_d = torch.exp(-(d_current - d_shortest))

    v = torch.gradient(states, spacing=(timestamps,), dim=0)[0]
    v_norm = torch.norm(v, dim=1)
    d_norm = d_current
    v_des = desired_velocity(d_norm)
    f_v = -torch.square(v_des - v_norm)

    a = torch.gradient(v, spacing=(timestamps,), dim=0)[0]
    acc_diff = (a[1:] - a[:-1]) / (timestamps[1:] - timestamps[:-1]).unsqueeze(1)
    jerk = torch.norm(acc_diff, dim=1)**2

    vel_diff = (v[1:] - v[:-1]) / (timestamps[1:] - timestamps[:-1]).unsqueeze(1)
    acc = torch.norm(vel_diff, dim=1)**2

    fd_avg = f_d.mean()
    fv_avg = f_v.mean()
    fa_avg = acc.mean()
    fj_avg = jerk.mean()

    return torch.tensor([fd_avg, fv_avg, fa_avg, fj_avg])
