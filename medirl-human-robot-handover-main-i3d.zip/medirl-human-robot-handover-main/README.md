# MEDIRL for Human-Robot Handover

This repository provides a complete implementation of Maximum Entropy Deep Inverse Reinforcement Learning (MEDIRL) to predict handover targets based on partial hand trajectories.

## Features
- Implements MEDIRL formulation.
- Analytical features: distance to goal, velocity deviation, acceleration, jerk.
- Predicts most likely goal using Bayesian inference.

## Usage
```bash
python train.py
```
To predict a goal:
```python
from infer import predict_goal
partial_traj = (pos_list, goal, timestamps)  # partial trajectory
trajs_by_goal, _ = load_dummy_data()
pred_goal, probs = predict_goal(partial_traj, trajs_by_goal)
```

## Dataset
- Dummy 3D trajectories to 4 goals are generated synthetically.
- Replace `load_dummy_data()` with your real handover dataset as needed.

## Dataset Access
If you'd like to access the hand trajectory dataset used for training and evaluation in this project, please email:
mukundmitra@iisc.ac.in (Mukund Mitra)

## Citation
If you use this code or build upon this work, please cite:

[1] Mukund Mitra, Gyanig Kumar, Partha Pratim Chakrabarti, and Pradipta Biswas. 2025. Investigating Inverse Reinforcement Learning during Rapid Aiming Movement in Extended Reality and Human-Robot Interaction. J. Hum.-Robot Interact. ACM Transactions in Human Robot Interaction. https://doi.org/10.1145/3736423

[2] Mukund Mitra, Preetam Pati, Vinay Krishna Sharma, Subin Raj, Partha Pratim Chakrabarti, and Pradipta Biswas. 2023. Comparison of Target Prediction in VR and MR using Inverse Reinforcement Learning. In Companion Proceedings of the 28th International Conference on Intelligent User Interfaces (IUI '23 Companion). Association for Computing Machinery, New York, NY, USA, 55–58. https://doi.org/10.1145/3581754.3584130

